# Nebula Launcher

Native Android launcher foundation inspired by ColorOS-style glass UI. Minimum Android version: Android 11 (API 30).

## Implemented in this revision
- Home screen with live clock and date
- Layered translucent glass-style cards and ambient gradients
- App drawer populated from launchable apps
- Live app search and app launching
- Long-press an app to open its Android App info page
- Swipe up on the home screen to open the drawer
- Swipe down on the home screen to open Nebula appearance settings
- Wallpaper picker and Android Settings shortcuts
- Persistent accent colour, icon size, drawer column count, and glass opacity preferences
- GitHub Actions workflow for a debug APK build

## Build
Open the project in Android Studio (Jellyfish or newer), allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Alternatively, push the project to a GitHub repository and run **Actions > Build Nebula Launcher APK**. Download the `NebulaLauncher-debug-apk` artifact from the completed workflow run.

## Set as default
Install the APK, press Home, and choose Nebula Launcher. Or select it under **Settings > Apps > Default apps > Home app**.

## Compatibility notes
- Android 11+ (API 30+) is required.
- This version uses translucent layered surfaces rather than real-time background blur. Android 11 does not expose the newer public `RenderEffect` blur API.
- This revision does not yet implement Android home-screen AppWidget hosting, notification badges, or a custom system control centre.
- The project is an initial development build; test on the target device before relying on it as the daily launcher.

## Blur and notification badges (v2)
- The home screen uses a blurred copy of the current wallpaper as its background. Android 12+ uses the platform RenderEffect blur; Android 11 uses the legacy RenderScript blur fallback.
- App-drawer notification badges count active, non-ongoing notifications by package. Android does not grant notification access automatically: open Customize → Enable notification access and explicitly enable Nebula Launcher in Android Settings.
- Some apps suppress notifications, group notifications, or provide their own badge policy. Counts therefore represent active notifications visible to Android, not necessarily an app's exact unread-message count.
