package com.nebula.launcher

import android.content.Intent
import android.os.Bundle
import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.service.notification.StatusBarNotification
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class LaunchableApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)
private val NebulaBlue = Color(0xFF83BFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(10, 16, 32)
        window.navigationBarColor = android.graphics.Color.rgb(10, 16, 32)
        setContent { NebulaHome() }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
private fun NebulaHome() {
    val context = LocalContext.current
    val pm = context.packageManager
    val prefs = remember { context.getSharedPreferences("nebula_preferences", android.content.Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf(emptyList<LaunchableApp>()) }
    var drawerOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var clock by remember { mutableStateOf("00:00") }
    var date by remember { mutableStateOf("") }
    var iconSize by remember { mutableFloatStateOf(prefs.getFloat("icon_size", 50f)) }
    var columns by remember { mutableIntStateOf(prefs.getInt("columns", 4).coerceIn(3, 6)) }
    var glassStrength by remember { mutableFloatStateOf(prefs.getFloat("glass", 0.15f).coerceIn(0.08f, 0.30f)) }
    var accentIndex by remember { mutableIntStateOf(prefs.getInt("accent", 0).coerceIn(0, 2)) }
    var badgeCounts by remember { mutableStateOf(readBadgeCounts(context)) }
    var blurredWallpaper by remember { mutableStateOf(loadBlurredWallpaper(context)) }
    val accents = listOf(NebulaBlue, Color(0xFFC5A2FF), Color(0xFF8FE3D0))
    val accent = accents[accentIndex]

    fun loadApps() {
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(launchIntent, 0)
            .mapNotNull { info -> runCatching {
                LaunchableApp(info.loadLabel(pm).toString(), info.activityInfo.packageName, info.loadIcon(pm))
            }.getOrNull() }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    LaunchedEffect(Unit) {
        loadApps()
        while (true) {
            badgeCounts = readBadgeCounts(context)
            val now = Date()
            clock = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
            delay(2_000)
        }
    }

    val visibleApps = apps.filter { it.label.contains(search.trim(), ignoreCase = true) }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.linearGradient(listOf(Color(0xFF0A1020), Color(0xFF29234C), Color(0xFF101B2D))))
            .pointerInput(drawerOpen, settingsOpen) {
                if (!drawerOpen && !settingsOpen) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onVerticalDrag = { change, amount -> total += amount; change.consume() },
                        onDragEnd = { if (total < -45f) drawerOpen = true else if (total > 45f) settingsOpen = true; total = 0f }
                    )
                }
            }
    ) {
        // The wallpaper itself is blurred before glass surfaces are drawn over it.
        blurredWallpaper?.let { bmp ->
            Image(bitmap = bmp.asImageBitmap(), contentDescription = null,
                modifier = Modifier.fillMaxSize().graphicsLayer { alpha = 0.82f }, contentScale = androidx.compose.ui.layout.ContentScale.Crop)
        }
        // Soft ambient light and layered translucent surfaces.
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(accent.copy(alpha = .24f), Color.Transparent), radius = 900f)))
        AnimatedVisibility(visible = !drawerOpen, enter = fadeIn(), exit = fadeOut()) {
            Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 36.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("NEBULA", color = Color.White.copy(alpha = .76f), fontSize = 12.sp, letterSpacing = 6.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(30.dp))
                    Text(clock, color = Color.White, fontSize = 70.sp, fontWeight = FontWeight.ExtraLight, letterSpacing = (-2).sp)
                    Text(date, color = Color.White.copy(alpha = .78f), fontSize = 15.sp)
                    Spacer(Modifier.height(30.dp))
                    GlassPanel(glassStrength, Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("A little space, just for you.", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(7.dp))
                            Text("Swipe up for apps · Swipe down for settings", color = Color.White.copy(alpha = .72f), fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    GlassPanel(glassStrength, Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(9.dp).clip(CircleShape).background(accent))
                            Spacer(Modifier.width(10.dp))
                            Text("Nebula is ready", color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Text("11+", color = Color.White.copy(alpha = .6f), fontSize = 11.sp)
                        }
                    }
                }
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        QuickAction("Apps", Icons.Default.Apps, accent) { drawerOpen = true }
                        QuickAction("Wallpaper", Icons.Default.Wallpaper, accent) {
                            runCatching { context.startActivity(Intent(Intent.ACTION_SET_WALLPAPER)) }
                        }
                        QuickAction("Customize", Icons.Default.Palette, accent) { settingsOpen = true }
                        QuickAction("Settings", Icons.Default.Settings, accent) {
                            runCatching { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    GlassPanel(glassStrength, Modifier.fillMaxWidth().combinedClickable(onClick = { drawerOpen = true }, onLongClick = { settingsOpen = true })) {
                        Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Search, null, tint = Color.White.copy(alpha = .85f))
                            Spacer(Modifier.width(12.dp))
                            Text("Search your apps", color = Color.White.copy(alpha = .78f), fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        AnimatedVisibility(visible = drawerOpen, enter = fadeIn(), exit = fadeOut()) {
            Column(Modifier.fillMaxSize().padding(top = 28.dp, start = 18.dp, end = 18.dp, bottom = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Apps", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("${visibleApps.size}", color = Color.White.copy(alpha = .6f), fontSize = 12.sp)
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = { drawerOpen = false; search = "" }) { Icon(Icons.Default.ArrowBack, "Close app drawer", tint = Color.White) }
                }
                Spacer(Modifier.height(12.dp))
                GlassPanel(glassStrength, Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, null, tint = Color.White.copy(alpha = .7f))
                        Spacer(Modifier.width(10.dp))
                        BasicTextField(value = search, onValueChange = { search = it }, singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                            modifier = Modifier.weight(1f), decorationBox = { inner ->
                                if (search.isEmpty()) Text("Find an app", color = Color.White.copy(alpha = .5f), fontSize = 15.sp)
                                inner()
                            })
                    }
                }
                Spacer(Modifier.height(18.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(columns), contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(visibleApps, key = { it.packageName }) { app ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.combinedClickable(
                                onClick = { pm.getLaunchIntentForPackage(app.packageName)?.let { runCatching { context.startActivity(it) } } },
                                onLongClick = { runCatching { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = android.net.Uri.parse("package:${app.packageName}") }) } }
                            ).padding(vertical = 5.dp)) {
                            Box {
                                AndroidAppIcon(app.icon, app.label, iconSize.dp)
                                val badge = badgeCounts[app.packageName] ?: 0
                                if (badge > 0) {
                                    Box(Modifier.align(Alignment.TopEnd).offset(x = 5.dp, y = (-4).dp)
                                        .defaultMinSize(minWidth = 18.dp, minHeight = 18.dp)
                                        .clip(CircleShape).background(Color(0xFFFF435A)).padding(horizontal = 5.dp),
                                        contentAlignment = Alignment.Center) {
                                        Text(if (badge > 99) "99+" else badge.toString(), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(Modifier.height(7.dp))
                            Text(app.label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }

        if (settingsOpen) {
            ModalBottomSheet(onDismissRequest = { settingsOpen = false }, containerColor = Color(0xFF20243A), contentColor = Color.White) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 30.dp)) {
                    Text("Nebula appearance", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(18.dp))
                    Text("Accent colour", color = Color.White.copy(alpha = .7f), fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        accents.forEachIndexed { index, color ->
                            Box(Modifier.size(38.dp).clip(CircleShape).background(color).combinedClickable(onClick = {
                                accentIndex = index; prefs.edit().putInt("accent", index).apply()
                            }))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("App icon size · ${iconSize.toInt()} dp", fontSize = 13.sp)
                    Slider(value = iconSize, onValueChange = { iconSize = it }, valueRange = 40f..68f, onValueChangeFinished = { prefs.edit().putFloat("icon_size", iconSize).apply() })
                    Text("App drawer columns · $columns", fontSize = 13.sp)
                    Slider(value = columns.toFloat(), onValueChange = { columns = it.toInt().coerceIn(3, 6) }, valueRange = 3f..6f, steps = 2, onValueChangeFinished = { prefs.edit().putInt("columns", columns).apply() })
                    Text("Glass opacity · ${(glassStrength * 100).toInt()}%", fontSize = 13.sp)
                    Slider(value = glassStrength, onValueChange = { glassStrength = it }, valueRange = .08f.. .30f, onValueChangeFinished = { prefs.edit().putFloat("glass", glassStrength).apply() })
                    Spacer(Modifier.height(8.dp))
                    Text("Notification badges", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("Allow notification access so Nebula can show unread notification counts on app icons.", color = Color.White.copy(alpha = .65f), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }) {
                        Text("Enable notification access")
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Blur uses your current wallpaper. Android 12+ supports the system blur pipeline; Android 11 uses a pre-blurred wallpaper fallback.", color = Color.White.copy(alpha = .58f), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun GlassPanel(opacity: Float, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(27.dp))
        .background(Color(0xFFBFD8FF).copy(alpha = opacity + .035f))
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = .20f), Color.White.copy(alpha = .035f))))
        .then(Modifier)) { content() }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.combinedClickable(onClick = onClick, onLongClick = onClick)) {
        Box(Modifier.size(55.dp).clip(CircleShape).background(Color.White.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = Color.White.copy(alpha = .86f), fontSize = 11.sp)
    }
}

@Composable
private fun AndroidAppIcon(drawable: android.graphics.drawable.Drawable, label: String, size: androidx.compose.ui.unit.Dp) {
    val bitmap = remember(drawable) {
        val bmp = android.graphics.Bitmap.createBitmap(128, 128, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        drawable.setBounds(0, 0, 128, 128)
        drawable.draw(canvas)
        bmp.asImageBitmap()
    }
    Image(bitmap = bitmap, contentDescription = label, modifier = Modifier.size(size))
}


private fun readBadgeCounts(context: android.content.Context): Map<String, Int> =
    context.getSharedPreferences("nebula_badges", android.content.Context.MODE_PRIVATE)
        .all.mapNotNull { (key, value) -> (value as? Int)?.takeIf { it > 0 }?.let { key to it } }.toMap()

private fun loadBlurredWallpaper(context: android.content.Context): Bitmap? = runCatching {
    val drawable = WallpaperManager.getInstance(context).drawable ?: return null
    val width = 720
    val height = 1280
    val source = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(source)
    drawable.setBounds(0, 0, width, height)
    drawable.draw(canvas)
    if (Build.VERSION.SDK_INT >= 31) {
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            renderEffect = android.graphics.RenderEffect.createBlurEffect(28f, 28f, android.graphics.Shader.TileMode.CLAMP)
        }
        Canvas(output).drawBitmap(source, 0f, 0f, paint)
        source.recycle()
        output
    } else {
        @Suppress("DEPRECATION")
        val rs = android.renderscript.RenderScript.create(context)
        @Suppress("DEPRECATION")
        val input = android.renderscript.Allocation.createFromBitmap(rs, source)
        val output = android.renderscript.Allocation.createTyped(rs, input.type)
        @Suppress("DEPRECATION")
        val blur = android.renderscript.ScriptIntrinsicBlur.create(rs, android.renderscript.Element.U8_4(rs))
        blur.setRadius(18f)
        blur.setInput(input)
        blur.forEach(output)
        output.copyTo(source)
        input.destroy(); output.destroy(); blur.destroy(); rs.destroy()
        source
    }
}.getOrNull()
