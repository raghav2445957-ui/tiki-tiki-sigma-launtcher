package com.nebula.launcher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads active notifications only after the user explicitly grants notification access. */
class NebulaNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshCounts()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        refreshCounts()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        refreshCounts()
    }

    private fun refreshCounts() {
        val counts = runCatching {
            activeNotifications.orEmpty()
                .filterNot { it.isOngoing }
                .groupingBy { it.packageName }
                .eachCount()
        }.getOrDefault(emptyMap())
        val prefs = getSharedPreferences("nebula_badges", MODE_PRIVATE)
        prefs.edit().clear().apply {
            counts.forEach { (packageName, count) -> putInt(packageName, count) }
        }.apply()
    }
}
